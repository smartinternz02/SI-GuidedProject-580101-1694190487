package com.example.assignment3

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.assignment3.ui.theme.Assignment3Theme

class MainActivity : ComponentActivity() {
    private lateinit var butto: Button
    private lateinit var usern: EditText
    private lateinit var passw: EditText
    private lateinit var yt: ImageView
    private lateinit var gmail: ImageView
    private lateinit var git: ImageView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Set the content view to your layout
        setContentView(R.layout.layout)

        // Find the views by their IDs
        butto = findViewById(R.id.butto)
        usern = findViewById(R.id.usern)
        passw = findViewById(R.id.passw)
        yt=findViewById(R.id.yt)
        gmail=findViewById(R.id.gmail)
        git=findViewById(R.id.git)
        yt.setOnClickListener{
            openUrl1()
        }
        gmail.setOnClickListener{
            openUrl2()
        }
        git.setOnClickListener{
            openUrl3()
        }
    }
    private fun openUrl1()
    {
        val url = "https://www.youtube.com"
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
    }
    private fun openUrl2()
    {
        val url = "https://www.gmail.com"
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
    }
    private fun openUrl3()
    {
        val url = "https://www.github.com"
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
    }
}

