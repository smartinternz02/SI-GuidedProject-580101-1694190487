package com.example.assignment3

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.assignment3.ui.theme.Assignment3Theme
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.apache.poi.xssf.usermodel.XSSFWorkbook
import java.io.InputStream
import java.util.ArrayList

class MainActivity : AppCompatActivity() {

    private lateinit var recyclerView: RecyclerView
    private lateinit var foodList: ArrayList<Food>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        recyclerView = findViewById(R.id.recyclerView)
        foodList = ArrayList()

        try {
            readExcelFile("D:/prac/andstud", "food_list.xlsx")
        } catch (e: IOException) {
            e.printStackTrace()
        }

        val foodAdapter = FoodAdapter(foodList)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = foodAdapter
    }

    private fun findViewById(recyclerView: Any): Any {

    }

    @Throws(IOException::class)
    private fun readExcelFile(folderName: String, fileName: String) {
        val inputStream: InputStream = assets.open("$folderName/$fileName")
        val workbook: XSSFWorkbook = XSSFWorkbook(inputStream)
        val sheet: XSSFSheet = workbook.getSheetAt(0)

        for (row in sheet) {
            if (row.rowNum == 0) {
                continue
            }

            val foodNameCell = row.getCell(0)
            val restaurantNameCell = row.getCell(1)
            val priceCell = row.getCell(2)

            val foodName = foodNameCell.stringCellValue
            val restaurantName = restaurantNameCell.stringCellValue
            val price = priceCell.numericCellValue

            val food = Food(foodName, restaurantName, price)
            foodList.add(food)
        }

        workbook.close()
        inputStream.close()
    }
}