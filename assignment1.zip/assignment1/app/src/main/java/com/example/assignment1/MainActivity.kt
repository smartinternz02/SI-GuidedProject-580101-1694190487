package com.example.assignment1

import android.content.Context
import android.os.Bundle
import android.widget.Space
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.assignment1.ui.theme.Assignment1Theme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {


        }
    }
}

@Composable
fun loginform(content:Context){
    Column(
        modifier=Modifier.fillMaxSize(),
        verticalArrangement=Arrangement.Center,
        horizontalAlignment=Alignment.CenterHorizontally
    ){
        var username = remember { mutableSetOf("")}
        var password = remember { mutableSetOf("")}

        Text(text="login", fontWeight= FontWeight.Bold,FontSize=35.sp)
        Spacer(modifier=Modifier.height(20.dp))
        OutlinedTextField(
            value = username,
            onValueChange = {username},
            label={Text(text = "username")},
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier=Modifier.height(20.dp))
        OutlinedTextField(
            value = password,
            onValueChange = {password},
            label={Text(text = "password")},
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier=Modifier.height(20.dp))
        Button(onClick = {},modifier= Modifier.fillMaxWidth()){
         Text(text="login", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
            
        }
    }

}